package com.skilldistillery.animalsanctuary;

public class Lion extends Carnivore {
	public Lion() {

	}

	public Lion(String name) {
		this.firstName = name;
	}

	public void makeNoise() {
		System.out.println("This is delicious and nutritious! ");
	}

}
