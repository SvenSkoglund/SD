package com.skilldistillery.animalsanctuary;

public class Herbivore extends Animals {

	public Herbivore() {

	}

	public Herbivore(String name) {
		this.firstName = name;
	}
}
