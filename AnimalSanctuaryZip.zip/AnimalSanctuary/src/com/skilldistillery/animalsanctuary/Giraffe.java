package com.skilldistillery.animalsanctuary;

public class Giraffe extends Herbivore {

	public Giraffe() {

	}

	public Giraffe(String name) {
		this.firstName = name;
	}

	public void makeNoise() {
		System.out.println("I think very highly of myself. ");
	}

}
