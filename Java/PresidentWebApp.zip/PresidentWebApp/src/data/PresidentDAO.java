package data;

public interface PresidentDAO {
  public President getPresidentByTerm(String term);
}
