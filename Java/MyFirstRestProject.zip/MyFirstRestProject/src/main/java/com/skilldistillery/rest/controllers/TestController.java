package com.skilldistillery.rest.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api")
public class TestController {

	
	@RequestMapping(path = "ping", method=RequestMethod.GET)
	public String ping() {
		return "pong";
	}
	
	@RequestMapping(path = "hello/{name}", method=RequestMethod.GET)
	public String hello(@PathVariable String name) {
		return "Hello " + name;
	}
}
