package com.skilldistillery.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstRestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstRestProjectApplication.class, args);
	}
}
