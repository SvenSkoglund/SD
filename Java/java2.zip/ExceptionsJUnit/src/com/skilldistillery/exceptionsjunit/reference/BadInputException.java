package com.skilldistillery.exceptionsjunit.reference;

@SuppressWarnings("serial")
public class BadInputException extends Exception {

}
