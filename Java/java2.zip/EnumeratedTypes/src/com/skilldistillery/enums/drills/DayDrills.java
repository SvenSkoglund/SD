package com.skilldistillery.enums.drills;

public class DayDrills {

  // Create a method called printDay that takes a Day argument and 
  // prints it to the screen with System.out.println.
  
  // If the day is FRIDAY, SATURDAY, or SUNDAY, print the message
  // "Weekend!"
  
  private void run() {
    // call printDay with several Day values.
  }
  
  public static void main(String[] args) {
    DayDrills d = new DayDrills();
    d.run();
  }

}
