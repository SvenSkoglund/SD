package com.skilldistillery.datesandtimes.drills;

public class TimeDrill {

  public static void main(String[] args) {
    // Create a LocalDate and a LocalTime representing the current
    // date and time.
    
    // Print both out.
    
    // Use the LocalTime above to create a LocalTime for 90 minutes in the future, and print it out.

    // What happens if you use your original LocalTime to create a LocalTime for 22 hours in the future?

  }

}
