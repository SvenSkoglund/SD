package com.skilldistillery.datesandtimes.drills;

public class IntervalDrill {

  public static void main(String[] args) {
    IntervalDrill drill = new IntervalDrill();
    drill.launch();
  }

  private void launch() {
    // Create a LocalDate representing the start date of your cohort.
    
    // Create a LocalDate representing today.
    
    // Print out both dates.
    
    // Create a Period object representing the interval between the two dates, and print it.
    
    // Create a LocalTime representing when you arrived today.
    
    // Create a LocalTime representing now.
    
    // Print out both times.
    
    // Create a Duration object for the interval between now and when you arrived, and print it.
    
    // What happens if you try to create a Duration representing
    // the interval between your cohort start date and today?
  }

}
