package com.skilldistillery.games.whiterabbit.items;

public interface Labelable {

	public String getLabel() ;
}
