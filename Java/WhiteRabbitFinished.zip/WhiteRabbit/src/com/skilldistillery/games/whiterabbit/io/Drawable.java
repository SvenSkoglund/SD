package com.skilldistillery.games.whiterabbit.io;

public interface Drawable {
  void draw();
}
