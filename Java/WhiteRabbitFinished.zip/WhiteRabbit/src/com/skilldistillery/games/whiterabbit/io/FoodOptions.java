package com.skilldistillery.games.whiterabbit.io;

public class FoodOptions implements Drawable {

	@Override
	public void draw() {
	//s	System.out.println("You see a piece of food. What would you like to do. ");
		System.out.println("1. Eat the food.");
		System.out.println("2. Ignore the food.");

	}

}
