package com.skilldistillery.games.whiterabbit.io;

public class DrinkOptions implements Drawable {

	@Override
	public void draw() {
	//s	System.out.println("You see a piece of food. What would you like to do. ");
		System.out.println("1. Drink the juice.");
		System.out.println("2. Ignore the drink.");

	}

}
