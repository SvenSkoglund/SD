package com.skilldistillery.games.whiterabbit.items;

public interface FoodFactory {

	Food getFood();

	void ignoreFood();
}
