package com.skilldistillery.games.whiterabbit.io;

public class PromptForName implements Drawable {

	@Override
	public void draw() {
	System.out.println("What is your name? ");

	}

}
