package com.skilldistillery.subinit.solutions;

public class InitializationDemo2 {

  public static void main(String[] args) {
    System.out.println("main start.");
    
    SubClass sub = new SubClass();
    
    System.out.println("main end.");

  }

}
