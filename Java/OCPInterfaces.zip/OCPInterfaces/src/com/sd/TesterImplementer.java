package com.sd;

interface Tester1 {
  double doIt();
}

interface Tester2 {
  int doIt();
}

// Change TesterImplementer to implement Tester1 and Tester2
public class TesterImplementer {
  
}
