package com.sd;

public interface Interface1 {
	final int CONSTANT_1 = 12;
	//int CONSTANT_2;
}
