package com.skilldistillery.unittesting.solutions;

public class Calculator {
  public int add(int first, int second) {
    return first + second;
  }
  
  public int subtract(int first, int second) {
    return first - second;
  }
  
  public int multiply(int first, int second) {
    return first * second;
  }
  
  public int divide(int numerator, int denominator) {
    return numerator / denominator;
  }
  
  public double divide(double numerator, double denominator) {
    return numerator / denominator;
  }
}
