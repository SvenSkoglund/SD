package com.skilldistillery.interfaces.reference.smarthome;

public class Fan implements Switchable {

  @Override
  public void turnOn() {
  }

  @Override
  public void turnOff() {
  }

  @Override
  public boolean isOn() {
    return false;
  }

}
