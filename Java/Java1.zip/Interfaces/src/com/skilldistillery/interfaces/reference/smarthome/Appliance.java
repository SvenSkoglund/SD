package com.skilldistillery.interfaces.reference.smarthome;

public abstract class Appliance {

}
