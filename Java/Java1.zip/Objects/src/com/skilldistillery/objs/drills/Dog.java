package com.skilldistillery.objs.drills;

public class Dog {
  public String breed;
  public String name;
  public int weight;
  
  // Add a constructor with parameters to initialize breed and weight.
  
  // Add a constructor with parameters to initialize name, breed, and weight.
 
  
  public void displayDogInfo() {
    System.out.println("Dog [breed=" + breed + ", name=" + name + ", weight=" + weight + "]");
  }

  public static void main(String[] args) {
    // Create three dog instances and call the displayDogInfo method on each Dog object.

  }

}
