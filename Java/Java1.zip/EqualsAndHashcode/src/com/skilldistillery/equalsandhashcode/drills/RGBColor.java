package com.skilldistillery.equalsandhashcode.drills;

public class RGBColor {
  private int redValue;
  private int greenValue;
  private int blueValue;
  
  public RGBColor(int r, int g, int b) {
    redValue = r;
    greenValue = g;
    blueValue = b;
  }

}
