package com.skilldistillery.inheritance.solutions;

public class Employee extends Person {
  private String title;
  private double salary;
  
  /*public Employee() {
    When we do not supply any constructors, Java adds a public no-arg
    constructor called the "default constructor."
  }*/
  
}
