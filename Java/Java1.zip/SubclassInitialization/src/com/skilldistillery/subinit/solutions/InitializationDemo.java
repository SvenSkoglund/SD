package com.skilldistillery.subinit.solutions;

public class InitializationDemo {

  public static void main(String[] args) {
    System.out.println("main start.");
    
    SuperClass sup = new SuperClass();
    
    System.out.println("main end.");

  }

}
