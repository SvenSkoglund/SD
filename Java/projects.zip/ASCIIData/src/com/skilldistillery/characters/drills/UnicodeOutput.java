package com.skilldistillery.characters.drills;

public class UnicodeOutput {

  public static void main(String[] args) {
    // Write the characters 
    System.out.println( '\u261d' + '\u270a'+ '\u270b'+ '\u270c' );
    // to the screen.
    System.out.println('\u261d');
    System.out.println('\u270a');
    System.out.println('\u270b');
    System.out.println('\u270c');


  }

}
