package labs;

public class Pow2 {

	public static void main(String[] args) {
		
		int base = 2;
		for (int i = 2 ; i <= 32 ; i++) {
			System.out.println("" + i + " | " + base );
			base = base * 2;
			
			
		}
		
	}

}
