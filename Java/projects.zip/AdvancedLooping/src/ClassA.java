
public class ClassA {
	String s = "hello";

	public static void main(String[] args) {
		ClassB cb = new ClassB();
		
	}

public class ClassB extends ClassA {

}


}