package com.skilldistillery.daopattern.drills;

import java.util.List;

public interface PresidentDAO {
  List<President> getPresidents();
}
