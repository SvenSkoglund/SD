package com.skilldistillery.advancedarrays.drills;

public class PopStar {
	public String name;

	public void sing() {
		// Have the PopStar print their name to the screen, as part of some kind of
		// lyric.
		// Be creative.
		System.out.println(name + " wants to sing you a song");
	}
}
