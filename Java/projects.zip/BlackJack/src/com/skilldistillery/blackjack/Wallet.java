package com.skilldistillery.blackjack;

public class Wallet {
	private int balance;

	Wallet(int balance) {
		this.balance = balance;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

}
