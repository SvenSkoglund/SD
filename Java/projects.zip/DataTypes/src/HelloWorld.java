
public class HelloWorld {

	public static void main(String[] args) {

		System.out.println(5*5+1000);
		
		
	}

}
