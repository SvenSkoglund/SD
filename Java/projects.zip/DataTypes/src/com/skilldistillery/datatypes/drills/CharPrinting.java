package com.skilldistillery.datatypes.drills;

public class CharPrinting {

  public static void main(String[] args) {
    char variable = 'A';
    System.out.println(variable);
 
System.out.println(variable + 1);
  }

}
