*** JDBC Film Query Project

This project connects Java to a MySql database and retrieves information related to films and actors.

We used the JDBC packages and classes to connect to the database and retrieve its information. We also used SQL queries, including joins, to find data and use it to populate fields in our Java Objects. We used Maven to add sql dependencies for the project.
