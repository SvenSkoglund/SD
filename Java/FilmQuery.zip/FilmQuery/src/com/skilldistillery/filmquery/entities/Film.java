package com.skilldistillery.filmquery.entities;

public class Film {
}
